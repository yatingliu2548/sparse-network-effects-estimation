for script in *.sh
do
    sbatch "$script"
done
